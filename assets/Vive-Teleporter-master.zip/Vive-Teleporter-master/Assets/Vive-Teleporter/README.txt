For usage instructions / tutorial, go to:

https://github.com/Flafla2/Vive-Teleporter#getting-started

For legal information / licencing details see LICENSE.txt